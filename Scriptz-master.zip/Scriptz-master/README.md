# Scriptz

[![build_status](https://img.shields.io/badge/build-passing-brightgreen.svg)](https://github.com/cyfrost/Scriptz/releases/latest)
[![GitHub release](https://img.shields.io/badge/current%20release-v0.1-blue.svg)](https://github.com/cyfrost/Scriptz/releases/latest)
[![license](https://img.shields.io/badge/license-MIT-orange.svg)](https://github.com/cyfrost/Scriptz/blob/master/LICENSE)
[![HitCount](http://hits.dwyl.com/cyfrost/Scriptz.svg)](http://hits.dwyl.com/cyfrost/Scriptz)

Yet another quick-fix utility for Windows. 

## Download

Download the latest release from [here](https://github.com/cyfrost/Scriptz/releases/latest).

Compatible from Windows XP through 10.


## Screencaps

![img](https://i.imgur.com/EsKUC4h.png)

![img](https://i.imgur.com/GiR6Smg.png)


## Build Instructions

Use Visual Studio 2012 or higher.


## License

Copyright (c) 2018 cyfrost.

Licensed under the [MIT License](https://github.com/cyfrost/Scriptz/blob/master/LICENSE).
