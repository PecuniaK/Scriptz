﻿'The MIT License (MIT)
'---------------------
'
'Scriptz - a quick fix utilbox for Windows 7 and higher'

'Copyright © 2018 cyfrost <cyrus.frost@hotmail.com>
'
'Permission is hereby granted, free of charge, to any person obtaining 
'a copy of this software and associated documentation files (the "Software"),
'to deal in the Software without restriction, including without limitation
'the rights to use, copy, modify, merge, publish, distribute, sublicense,
'and/or sell copies of the Software, and to permit persons to whom the
'Software is furnished to do so, subject to the following conditions:
'
'The above copyright notice and this permission notice shall be included in all copies
'or substantial portions of the Software.
'
'THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED,
'INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
'PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE
'FOR AND CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
'OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
'DEALINGS IN THE SOFTWARE.

Public Class Form1

    Public appname As String = My.Application.Info.AssemblyName

    Public desc As String = My.Application.Info.Description


    Public version As String = "version " + My.Application.Info.Version.ToString() + " (build " + Month(DateTime.Now).ToString() + DateTime.Now.ToString("yy") + ")"



    Public copyright As String = My.Application.Info.Copyright





    Dim c As String = AppDomain.CurrentDomain.BaseDirectory + "bin\"
    Dim ProcExplorerBin32 As String = c + "ProcessExplorer\procexp.exe"
    Dim ProcExplorerBin64 As String = c + "ProcessExplorer\procexp64.exe"
    Dim AutorunsBin32 As String = c + "Autoruns\Autoruns.exe"
    Dim AutorunsBin64 As String = c + "Autoruns\Autoruns64.exe"
    Dim RegEditorBin32 As String = c + "ooregeditor\OORegEdt32.exe"
    Dim RegEditorBin As String = c + "ooregeditor\OORegEdt.exe"
    Dim GregDOSShellBin As String = c + "GS\gs.exe"











    Private Sub Form1_FormClosing(ByVal sender As Object, ByVal e As FormClosingEventArgs) Handles Me.FormClosing




    End Sub

    Private Function AskLogout()
        Dim res = MessageBox.Show("The user must log off and then login again for the change to take effect. Would you like to logoff now?", appname, MessageBoxButtons.YesNo, MessageBoxIcon.Information)
        If res = DialogResult.Yes Then
            Try
                Dim p As New Process
                p.StartInfo.FileName = c + "logoff.bat"

                p.Start()
                p.WaitForExit()


            Catch ex As Exception
                MessageBox.Show("Error: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End Try
        End If
        Return Nothing


    End Function



    Private Function Run(ByVal ref As String, ByVal msg As String)
        Try
            Dim p As New Process
            p.StartInfo.FileName = c + ref

            p.Start()
            p.WaitForExit()
            MessageBox.Show(msg, appname, MessageBoxButtons.OK, MessageBoxIcon.Information)

        Catch ex As Exception
            MessageBox.Show("Error: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Function

    Private Function RunProc(ByVal ref As String)
        Try
            Process.Start(ref)

        Catch ex As Exception
            MessageBox.Show("Error: " + ex.Message, "Scriptz", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Function



    Private Function isXP() As Boolean
        Dim osInfo As OperatingSystem = Environment.OSVersion

        Select Case osInfo.Version.Major
            Case 5
                Return True
        End Select
        Return False

    End Function

    Protected Overrides Function ProcessCmdKey(ByRef msg As Message, keyData As Keys) As Boolean
        If keyData = Keys.Escape Then


            Dim result As Integer = MessageBox.Show("Are you sure you want to exit?", appname, MessageBoxButtons.YesNo, MessageBoxIcon.Question)

            If result = DialogResult.Yes Then
                Me.Close()
                Return True
            End If



        End If
        Return MyBase.ProcessCmdKey(msg, keyData)


    End Function

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As EventArgs) Handles MyBase.Load
        If isXP() Then
            MessageBox.Show("Warning: Some features may not work correctly due to the limitations in Windows XP", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning)

        End If

        Me.Text = appname
    End Sub



    Private Sub LinkLabel2_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles LinkLabel2.LinkClicked
        Run("writeprotect.bat", "Success!")
        AskLogout()
    End Sub



    Private Function is64BitWindows() As Boolean
        If IntPtr.Size = 8 Then
            Return True
        ElseIf IntPtr.Size = 4 Then
            Return False
        End If

    End Function
    Private Sub LinkLabel4_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles LinkLabel4.LinkClicked
        Run("enablecmd.bat", "Success!")





    End Sub

    Private Sub LinkLabel11_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles LinkLabel11.LinkClicked
        Run("enableregedit.vbs", "Success!")


    End Sub

    Private Sub LinkLabel6_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles LinkLabel6.LinkClicked
        Run("enabletaskmanager.bat", "Success!")


    End Sub

    Private Sub LinkLabel15_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles LinkLabel15.LinkClicked
        Run("enablecontrolpanel.bat", "Success!")

    End Sub

    Private Sub LinkLabel9_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles LinkLabel9.LinkClicked
        Run("savesettings.bat", "Success!")
        AskLogout()
    End Sub

    Private Sub LinkLabel34_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles LinkLabel34.LinkClicked
        Run("enablefolderoptions.bat", "Success!")
        AskLogout()

    End Sub

    Private Sub LinkLabel33_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles LinkLabel33.LinkClicked
        Run("enablerun.bat", "Success!")
        AskLogout()
    End Sub


    Private Sub LinkLabel31_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles LinkLabel31.LinkClicked
        Run("enableadmin.cmd", "Success!")

    End Sub

    Private Sub LinkLabel30_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles LinkLabel30.LinkClicked
        Run("enableupdate.bat", "Success!")

    End Sub

    Private Sub LinkLabel10_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles LinkLabel10.LinkClicked
        Run("nowriteprotect.bat", "Success!")
        AskLogout()


    End Sub

    Private Sub LinkLabel13_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles LinkLabel13.LinkClicked
        Run("disablecmd.bat", "Success!")

    End Sub

    Private Sub LinkLabel12_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles LinkLabel12.LinkClicked
        Run("disableregedit.bat", "Success!")



    End Sub

    Private Sub LinkLabel5_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles LinkLabel5.LinkClicked
        Run("disabletaskmanager.bat", "Success!")


    End Sub

    Private Sub LinkLabel7_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles LinkLabel7.LinkClicked
        Run("nocontrolpanel.bat", "Success!")

    End Sub

    Private Sub LinkLabel8_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles LinkLabel8.LinkClicked
        Run("nosavesettings.bat", "Success!")
        AskLogout()

    End Sub

    Private Sub LinkLabel17_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles LinkLabel17.LinkClicked
        Run("nofolderoptions.bat", "Success!")
        AskLogout()

    End Sub

    Private Sub LinkLabel20_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles LinkLabel20.LinkClicked
        Run("norun.bat", "Success!")
        AskLogout()

    End Sub


    Private Sub LinkLabel27_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles LinkLabel27.LinkClicked
        Run("noadmin.cmd", "Success!")


    End Sub

    Private Sub LinkLabel26_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles LinkLabel26.LinkClicked
        Run("noupdate.cmd", "Success!")


    End Sub

    Private Sub LinkLabel36_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles LinkLabel36.LinkClicked
        Run("enablehibernation.bat", "Success!")


    End Sub

    Private Sub LinkLabel35_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles LinkLabel35.LinkClicked
        Run("disablehibernation.bat", "Success!")

    End Sub

    Private Sub LinkLabel38_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles LinkLabel38.LinkClicked
        Run("enablewsh.bat", "Success!")
        AskLogout()
    End Sub

    Private Sub LinkLabel37_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles LinkLabel37.LinkClicked
        Run("disablewsh.bat", "Success!")
        AskLogout()

    End Sub

    Private Sub LinkLabel21_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles LinkLabel21.LinkClicked
        Run("enablesafeboot.bat", "Success!")


    End Sub

    Private Sub LinkLabel19_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles LinkLabel19.LinkClicked
        Run("disablesafeboot.bat", "Success!")


    End Sub

    Private Sub LinkLabel18_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles LinkLabel18.LinkClicked
        Run("enableprefetcher.bat", "Success!")

    End Sub

    Private Sub LinkLabel16_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles LinkLabel16.LinkClicked
        Run("disableprefetcher.bat", "Success!")

    End Sub

    Private Sub LinkLabel24_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles LinkLabel24.LinkClicked
        Run("usbenableport.bat", "Success!")
        AskLogout()
    End Sub

    Private Sub LinkLabel22_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles LinkLabel22.LinkClicked
        Run("usbdisableport.bat", "Success!")
        AskLogout()

    End Sub

    Private Sub LinkLabel32_LinkClicked_1(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles LinkLabel32.LinkClicked
        RunProc("cmd.exe")

    End Sub

    Private Sub LinkLabel28_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles LinkLabel28.LinkClicked
        RunProc("regedit.exe")

    End Sub

    Private Sub LinkLabel29_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles LinkLabel29.LinkClicked
        RunProc("taskmgr.exe")
    End Sub

    Private Sub LinkLabel41_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles LinkLabel41.LinkClicked
        RunProc("control.exe")
    End Sub

    Private Sub LinkLabel25_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles LinkLabel25.LinkClicked
        Run("enableuac.bat", "Success!")
        AskLogout()
    End Sub

    Private Sub LinkLabel23_LinkClicked_2(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles LinkLabel23.LinkClicked
        Run("disableuac.bat", "Success!")
        AskLogout()

    End Sub

    Private Sub ExitToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ExitToolStripMenuItem.Click
        Application.Exit()

    End Sub

    Private Sub AboutToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles AboutToolStripMenuItem.Click
        Dim f As New Form2
        f.ShowDialog()

    End Sub

    Private Sub ResetWindowsFirewallDefaultsToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ResetWindowsFirewallDefaultsToolStripMenuItem.Click
        Run("repairfirewall.bat", "Success!")

    End Sub


    Private Sub CommandPromptToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles CommandPromptToolStripMenuItem.Click

        RunProc("cmd.exe")
    End Sub

    Private Sub RegistryEditorToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles RegistryEditorToolStripMenuItem.Click
        RunProc("regedit.exe")
    End Sub

    Private Sub TaskManagerToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles TaskManagerToolStripMenuItem.Click
        RunProc("taskmgr.exe")
    End Sub

    Private Sub ControlPanelToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ControlPanelToolStripMenuItem.Click
        RunProc("control.exe")
    End Sub

    Private Sub SystemConfigurationUtilityToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles SystemConfigurationUtilityToolStripMenuItem.Click
        RunProc("msconfig.exe")
    End Sub

    Private Sub EnableAdministratorAccountToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles EnableAdministratorAccountToolStripMenuItem.Click
        Run("enableadmin.cmd", "Success!")



    End Sub

    Private Sub TaskSchedulerToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles TaskSchedulerToolStripMenuItem.Click
        RunProc("taskschd.msc")
    End Sub

    Private Sub MMCToolStripMenuItem_Click(sender As Object, e As EventArgs)
        RunProc("mmc.exe")
    End Sub

    Private Sub GroupPolicyEditorToolStripMenuItem_Click(sender As Object, e As EventArgs)
        RunProc("gpedit.msc")
    End Sub

    Private Sub ServicesToolStripMenuItem_Click(sender As Object, e As EventArgs)
        RunProc("services.msc")
    End Sub

    Private Sub TaskSchedulerToolStripMenuItem1_Click(sender As Object, e As EventArgs)
        RunProc("taskschd.msc")
    End Sub

    Private Sub EventViewerToolStripMenuItem_Click(sender As Object, e As EventArgs)
        RunProc("eventvwr.exe")
    End Sub

    Private Sub DiskManagementToolStripMenuItem_Click(sender As Object, e As EventArgs)
        RunProc("diskmgmt.msc")
    End Sub

    Private Sub DeviceManagementToolStripMenuItem_Click(sender As Object, e As EventArgs)
        RunProc("devmgmt.msc")
    End Sub

    Private Sub AddRevealToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles AddRevealToolStripMenuItem.Click
        Run("installreveal.cmd", "Success!")

    End Sub


    Private Sub AddCMDHereToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles AddCMDHereToolStripMenuItem.Click
        Run("addcmd.bat", "Success!")
    End Sub

    Private Sub AddTakeOwnershipToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles AddTakeOwnershipToolStripMenuItem.Click
        Run("installtcs.bat", "Success!")

    End Sub

    Private Sub AddToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles AddToolStripMenuItem.Click
        Run("addnotepadcontext.bat", "Success!")

    End Sub

    Private Sub PrefetchToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles PrefetchToolStripMenuItem.Click
        Run("prefetch.bat", "Success!")

    End Sub

    Private Sub RunMRUToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles RunMRUToolStripMenuItem.Click
        Run("clearrun.bat", "Success!")

    End Sub

    Private Sub DNSCacheToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles DNSCacheToolStripMenuItem.Click
        RunProc("C:\Windows\System32\ipconfig.exe /flushdns")
        RunProc("C:\Windows\System32\ipconfig.exe /renew")
    End Sub

    Private Sub RecentFilesToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles RecentFilesToolStripMenuItem.Click
        Run("mru.js", "Success!")

    End Sub

    Private Sub IEBrowsingActivityToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles IEBrowsingActivityToolStripMenuItem.Click
        Run("cleanie.cmd", "Success!")

    End Sub

    Private Sub ClearEventsViewerLogToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ClearEventsViewerLogToolStripMenuItem.Click
        Run("event.bat", "Success!")

    End Sub

    Private Sub GregsDOSShellToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles GregsDOSShellToolStripMenuItem.Click
        RunProc(GregDOSShellBin)


    End Sub



    Private Sub SafeREGEDITToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles SafeREGEDITToolStripMenuItem.Click
        If is64BitWindows() Then
            RunProc(RegEditorBin)
        Else
            RunProc(RegEditorBin32)

        End If


    End Sub



    Private Sub RestartExplorerToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles RestartExplorerToolStripMenuItem.Click

        Run("reexplore.cmd", "Success!")


    End Sub

    Private Sub ToolStripStatusLabel1_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub ProcessExplorer32BitToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ProcessExplorer32BitToolStripMenuItem.Click
        If is64BitWindows() Then
            RunProc(ProcExplorerBin64)
        Else
            RunProc(ProcExplorerBin32)

        End If

    End Sub



    Private Sub ServicesToolStripMenuItem_Click_1(sender As Object, e As EventArgs) Handles ServicesToolStripMenuItem.Click
        RunProc("services.msc")


    End Sub

    Private Sub MMCToolStripMenuItem_Click_1(sender As Object, e As EventArgs) Handles MMCToolStripMenuItem.Click
        RunProc("mmc.exe")

    End Sub

    Private Sub EventViewerToolStripMenuItem_Click_1(sender As Object, e As EventArgs) Handles EventViewerToolStripMenuItem.Click
        RunProc("eventvwr")

    End Sub

    Private Sub GroupPolicyEditorToolStripMenuItem_Click_1(sender As Object, e As EventArgs) Handles GroupPolicyEditorToolStripMenuItem.Click
        If System.IO.File.Exists("C:\Windows\System32\gpedit.msc") Then

            RunProc("gpedit.msc")

        Else
            MessageBox.Show("Group Policy editor is not supported on this version of Windows", appname, MessageBoxButtons.OK, MessageBoxIcon.Error)

        End If

    End Sub

    Private Sub DiskManagementToolStripMenuItem_Click_1(sender As Object, e As EventArgs) Handles DiskManagementToolStripMenuItem.Click
        RunProc("diskmgmt.msc")
    End Sub

    Private Sub DeviceManagementToolStripMenuItem_Click_1(sender As Object, e As EventArgs) Handles DeviceManagementToolStripMenuItem.Click
        RunProc("devmgmt.msc")
    End Sub

    Private Sub ToolStripMenuItem2_Click(sender As Object, e As EventArgs) Handles ToolStripMenuItem2.Click
        Run("explorerstartuprepair.bat", "Success!")
    End Sub

    Private Sub RunAutorunsToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles RunAutorunsToolStripMenuItem.Click
        If is64BitWindows() Then
            RunProc(AutorunsBin64)
        Else
            RunProc(AutorunsBin32)

        End If
    End Sub

    Private Sub GroupBox1_Enter(sender As Object, e As EventArgs) Handles GroupBox1.Enter

    End Sub
End Class
