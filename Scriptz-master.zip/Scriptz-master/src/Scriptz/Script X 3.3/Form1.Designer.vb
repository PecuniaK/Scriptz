﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.FileToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.RestartExplorerToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator1 = New System.Windows.Forms.ToolStripSeparator()
        Me.ExitToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.RepairToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ResetWindowsFirewallDefaultsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem2 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ClearToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.PrefetchToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.RunMRUToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.RecentFilesToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ClearEventsViewerLogToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.IEBrowsingActivityToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.DNSCacheToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator7 = New System.Windows.Forms.ToolStripSeparator()
        Me.SafeToolsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.GregsDOSShellToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SafeREGEDITToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ProcessExplorer32BitToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.RunAutorunsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.RecoveryToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.EnableAdministratorAccountToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator4 = New System.Windows.Forms.ToolStripSeparator()
        Me.CommandPromptToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.RegistryEditorToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.TaskManagerToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ControlPanelToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator5 = New System.Windows.Forms.ToolStripSeparator()
        Me.TaskSchedulerToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ServicesToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.EventViewerToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SystemConfigurationUtilityToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator3 = New System.Windows.Forms.ToolStripSeparator()
        Me.MMCToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.GroupPolicyEditorToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.DiskManagementToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.DeviceManagementToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator6 = New System.Windows.Forms.ToolStripSeparator()
        Me.ContextMenuToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AddRevealToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AddCMDHereToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AddTakeOwnershipToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AddToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.HelpToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AboutToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label35 = New System.Windows.Forms.Label()
        Me.Label37 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label42 = New System.Windows.Forms.Label()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.LinkLabel2 = New System.Windows.Forms.LinkLabel()
        Me.LinkLabel4 = New System.Windows.Forms.LinkLabel()
        Me.LinkLabel5 = New System.Windows.Forms.LinkLabel()
        Me.LinkLabel6 = New System.Windows.Forms.LinkLabel()
        Me.LinkLabel7 = New System.Windows.Forms.LinkLabel()
        Me.LinkLabel8 = New System.Windows.Forms.LinkLabel()
        Me.LinkLabel9 = New System.Windows.Forms.LinkLabel()
        Me.LinkLabel10 = New System.Windows.Forms.LinkLabel()
        Me.LinkLabel11 = New System.Windows.Forms.LinkLabel()
        Me.LinkLabel12 = New System.Windows.Forms.LinkLabel()
        Me.LinkLabel13 = New System.Windows.Forms.LinkLabel()
        Me.LinkLabel14 = New System.Windows.Forms.LinkLabel()
        Me.LinkLabel15 = New System.Windows.Forms.LinkLabel()
        Me.LinkLabel17 = New System.Windows.Forms.LinkLabel()
        Me.LinkLabel20 = New System.Windows.Forms.LinkLabel()
        Me.LinkLabel26 = New System.Windows.Forms.LinkLabel()
        Me.LinkLabel27 = New System.Windows.Forms.LinkLabel()
        Me.LinkLabel30 = New System.Windows.Forms.LinkLabel()
        Me.LinkLabel31 = New System.Windows.Forms.LinkLabel()
        Me.LinkLabel33 = New System.Windows.Forms.LinkLabel()
        Me.LinkLabel34 = New System.Windows.Forms.LinkLabel()
        Me.LinkLabel36 = New System.Windows.Forms.LinkLabel()
        Me.LinkLabel35 = New System.Windows.Forms.LinkLabel()
        Me.LinkLabel38 = New System.Windows.Forms.LinkLabel()
        Me.LinkLabel37 = New System.Windows.Forms.LinkLabel()
        Me.LinkLabel21 = New System.Windows.Forms.LinkLabel()
        Me.LinkLabel19 = New System.Windows.Forms.LinkLabel()
        Me.LinkLabel18 = New System.Windows.Forms.LinkLabel()
        Me.LinkLabel16 = New System.Windows.Forms.LinkLabel()
        Me.LinkLabel24 = New System.Windows.Forms.LinkLabel()
        Me.LinkLabel22 = New System.Windows.Forms.LinkLabel()
        Me.LinkLabel41 = New System.Windows.Forms.LinkLabel()
        Me.LinkLabel32 = New System.Windows.Forms.LinkLabel()
        Me.LinkLabel29 = New System.Windows.Forms.LinkLabel()
        Me.LinkLabel28 = New System.Windows.Forms.LinkLabel()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.LinkLabel25 = New System.Windows.Forms.LinkLabel()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.LinkLabel23 = New System.Windows.Forms.LinkLabel()
        Me.MenuStrip1.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'MenuStrip1
        '
        Me.MenuStrip1.BackColor = System.Drawing.Color.White
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.FileToolStripMenuItem, Me.ToolsToolStripMenuItem, Me.HelpToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(533, 24)
        Me.MenuStrip1.TabIndex = 128
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'FileToolStripMenuItem
        '
        Me.FileToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.RestartExplorerToolStripMenuItem, Me.ToolStripSeparator1, Me.ExitToolStripMenuItem})
        Me.FileToolStripMenuItem.Name = "FileToolStripMenuItem"
        Me.FileToolStripMenuItem.Size = New System.Drawing.Size(37, 20)
        Me.FileToolStripMenuItem.Text = "File"
        '
        'RestartExplorerToolStripMenuItem
        '
        Me.RestartExplorerToolStripMenuItem.Name = "RestartExplorerToolStripMenuItem"
        Me.RestartExplorerToolStripMenuItem.Size = New System.Drawing.Size(207, 22)
        Me.RestartExplorerToolStripMenuItem.Text = "Restart Windows Explorer"
        '
        'ToolStripSeparator1
        '
        Me.ToolStripSeparator1.Name = "ToolStripSeparator1"
        Me.ToolStripSeparator1.Size = New System.Drawing.Size(204, 6)
        '
        'ExitToolStripMenuItem
        '
        Me.ExitToolStripMenuItem.Name = "ExitToolStripMenuItem"
        Me.ExitToolStripMenuItem.Size = New System.Drawing.Size(207, 22)
        Me.ExitToolStripMenuItem.Text = "Exit"
        '
        'ToolsToolStripMenuItem
        '
        Me.ToolsToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.RepairToolStripMenuItem, Me.ClearToolStripMenuItem, Me.ToolStripSeparator7, Me.SafeToolsToolStripMenuItem, Me.RecoveryToolStripMenuItem, Me.ToolStripSeparator6, Me.ContextMenuToolStripMenuItem})
        Me.ToolsToolStripMenuItem.Name = "ToolsToolStripMenuItem"
        Me.ToolsToolStripMenuItem.Size = New System.Drawing.Size(47, 20)
        Me.ToolsToolStripMenuItem.Text = "Tools"
        '
        'RepairToolStripMenuItem
        '
        Me.RepairToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ResetWindowsFirewallDefaultsToolStripMenuItem, Me.ToolStripMenuItem2})
        Me.RepairToolStripMenuItem.Name = "RepairToolStripMenuItem"
        Me.RepairToolStripMenuItem.Size = New System.Drawing.Size(188, 22)
        Me.RepairToolStripMenuItem.Text = "Reset"
        '
        'ResetWindowsFirewallDefaultsToolStripMenuItem
        '
        Me.ResetWindowsFirewallDefaultsToolStripMenuItem.Name = "ResetWindowsFirewallDefaultsToolStripMenuItem"
        Me.ResetWindowsFirewallDefaultsToolStripMenuItem.Size = New System.Drawing.Size(279, 22)
        Me.ResetWindowsFirewallDefaultsToolStripMenuItem.Text = "Reset Windows Firewall settings"
        '
        'ToolStripMenuItem2
        '
        Me.ToolStripMenuItem2.Name = "ToolStripMenuItem2"
        Me.ToolStripMenuItem2.Size = New System.Drawing.Size(279, 22)
        Me.ToolStripMenuItem2.Text = "Reset Windows Explorer shell at startup"
        '
        'ClearToolStripMenuItem
        '
        Me.ClearToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.PrefetchToolStripMenuItem, Me.RunMRUToolStripMenuItem, Me.RecentFilesToolStripMenuItem, Me.ClearEventsViewerLogToolStripMenuItem, Me.IEBrowsingActivityToolStripMenuItem, Me.DNSCacheToolStripMenuItem})
        Me.ClearToolStripMenuItem.Name = "ClearToolStripMenuItem"
        Me.ClearToolStripMenuItem.Size = New System.Drawing.Size(188, 22)
        Me.ClearToolStripMenuItem.Text = "Clean-up"
        '
        'PrefetchToolStripMenuItem
        '
        Me.PrefetchToolStripMenuItem.Name = "PrefetchToolStripMenuItem"
        Me.PrefetchToolStripMenuItem.Size = New System.Drawing.Size(201, 22)
        Me.PrefetchToolStripMenuItem.Text = "Clear Prefetch cache"
        '
        'RunMRUToolStripMenuItem
        '
        Me.RunMRUToolStripMenuItem.Name = "RunMRUToolStripMenuItem"
        Me.RunMRUToolStripMenuItem.Size = New System.Drawing.Size(201, 22)
        Me.RunMRUToolStripMenuItem.Text = "Clear Run MRU"
        '
        'RecentFilesToolStripMenuItem
        '
        Me.RecentFilesToolStripMenuItem.Name = "RecentFilesToolStripMenuItem"
        Me.RecentFilesToolStripMenuItem.Size = New System.Drawing.Size(201, 22)
        Me.RecentFilesToolStripMenuItem.Text = "Clear Recents activity"
        '
        'ClearEventsViewerLogToolStripMenuItem
        '
        Me.ClearEventsViewerLogToolStripMenuItem.Name = "ClearEventsViewerLogToolStripMenuItem"
        Me.ClearEventsViewerLogToolStripMenuItem.Size = New System.Drawing.Size(201, 22)
        Me.ClearEventsViewerLogToolStripMenuItem.Text = "Clear Events Viewer logs"
        '
        'IEBrowsingActivityToolStripMenuItem
        '
        Me.IEBrowsingActivityToolStripMenuItem.Name = "IEBrowsingActivityToolStripMenuItem"
        Me.IEBrowsingActivityToolStripMenuItem.Size = New System.Drawing.Size(201, 22)
        Me.IEBrowsingActivityToolStripMenuItem.Text = "Clear IE history"
        '
        'DNSCacheToolStripMenuItem
        '
        Me.DNSCacheToolStripMenuItem.Name = "DNSCacheToolStripMenuItem"
        Me.DNSCacheToolStripMenuItem.Size = New System.Drawing.Size(201, 22)
        Me.DNSCacheToolStripMenuItem.Text = "Flush DNS cache"
        '
        'ToolStripSeparator7
        '
        Me.ToolStripSeparator7.Name = "ToolStripSeparator7"
        Me.ToolStripSeparator7.Size = New System.Drawing.Size(185, 6)
        '
        'SafeToolsToolStripMenuItem
        '
        Me.SafeToolsToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.GregsDOSShellToolStripMenuItem, Me.SafeREGEDITToolStripMenuItem, Me.ProcessExplorer32BitToolStripMenuItem, Me.RunAutorunsToolStripMenuItem})
        Me.SafeToolsToolStripMenuItem.Name = "SafeToolsToolStripMenuItem"
        Me.SafeToolsToolStripMenuItem.Size = New System.Drawing.Size(188, 22)
        Me.SafeToolsToolStripMenuItem.Text = "Third-party tools"
        '
        'GregsDOSShellToolStripMenuItem
        '
        Me.GregsDOSShellToolStripMenuItem.Name = "GregsDOSShellToolStripMenuItem"
        Me.GregsDOSShellToolStripMenuItem.Size = New System.Drawing.Size(185, 22)
        Me.GregsDOSShellToolStripMenuItem.Text = "Run Greg's DOS Shell"
        '
        'SafeREGEDITToolStripMenuItem
        '
        Me.SafeREGEDITToolStripMenuItem.Name = "SafeREGEDITToolStripMenuItem"
        Me.SafeREGEDITToolStripMenuItem.Size = New System.Drawing.Size(185, 22)
        Me.SafeREGEDITToolStripMenuItem.Text = "Run O&&O RegEditor"
        '
        'ProcessExplorer32BitToolStripMenuItem
        '
        Me.ProcessExplorer32BitToolStripMenuItem.Name = "ProcessExplorer32BitToolStripMenuItem"
        Me.ProcessExplorer32BitToolStripMenuItem.Size = New System.Drawing.Size(185, 22)
        Me.ProcessExplorer32BitToolStripMenuItem.Text = "Run Process Explorer"
        '
        'RunAutorunsToolStripMenuItem
        '
        Me.RunAutorunsToolStripMenuItem.Name = "RunAutorunsToolStripMenuItem"
        Me.RunAutorunsToolStripMenuItem.Size = New System.Drawing.Size(185, 22)
        Me.RunAutorunsToolStripMenuItem.Text = "Run Autoruns"
        '
        'RecoveryToolStripMenuItem
        '
        Me.RecoveryToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.EnableAdministratorAccountToolStripMenuItem, Me.ToolStripSeparator4, Me.CommandPromptToolStripMenuItem, Me.RegistryEditorToolStripMenuItem, Me.TaskManagerToolStripMenuItem, Me.ControlPanelToolStripMenuItem, Me.ToolStripSeparator5, Me.TaskSchedulerToolStripMenuItem, Me.ServicesToolStripMenuItem, Me.EventViewerToolStripMenuItem, Me.SystemConfigurationUtilityToolStripMenuItem, Me.ToolStripSeparator3, Me.MMCToolStripMenuItem, Me.GroupPolicyEditorToolStripMenuItem, Me.DiskManagementToolStripMenuItem, Me.DeviceManagementToolStripMenuItem})
        Me.RecoveryToolStripMenuItem.Name = "RecoveryToolStripMenuItem"
        Me.RecoveryToolStripMenuItem.Size = New System.Drawing.Size(188, 22)
        Me.RecoveryToolStripMenuItem.Text = "System tools"
        '
        'EnableAdministratorAccountToolStripMenuItem
        '
        Me.EnableAdministratorAccountToolStripMenuItem.Name = "EnableAdministratorAccountToolStripMenuItem"
        Me.EnableAdministratorAccountToolStripMenuItem.Size = New System.Drawing.Size(247, 22)
        Me.EnableAdministratorAccountToolStripMenuItem.Text = "Enable Administrator Account"
        '
        'ToolStripSeparator4
        '
        Me.ToolStripSeparator4.Name = "ToolStripSeparator4"
        Me.ToolStripSeparator4.Size = New System.Drawing.Size(244, 6)
        '
        'CommandPromptToolStripMenuItem
        '
        Me.CommandPromptToolStripMenuItem.Name = "CommandPromptToolStripMenuItem"
        Me.CommandPromptToolStripMenuItem.Size = New System.Drawing.Size(247, 22)
        Me.CommandPromptToolStripMenuItem.Text = "Run Command Prompt"
        '
        'RegistryEditorToolStripMenuItem
        '
        Me.RegistryEditorToolStripMenuItem.Name = "RegistryEditorToolStripMenuItem"
        Me.RegistryEditorToolStripMenuItem.Size = New System.Drawing.Size(247, 22)
        Me.RegistryEditorToolStripMenuItem.Text = "Run Registry Editor"
        '
        'TaskManagerToolStripMenuItem
        '
        Me.TaskManagerToolStripMenuItem.Name = "TaskManagerToolStripMenuItem"
        Me.TaskManagerToolStripMenuItem.Size = New System.Drawing.Size(247, 22)
        Me.TaskManagerToolStripMenuItem.Text = "Run Task Manager"
        '
        'ControlPanelToolStripMenuItem
        '
        Me.ControlPanelToolStripMenuItem.Name = "ControlPanelToolStripMenuItem"
        Me.ControlPanelToolStripMenuItem.Size = New System.Drawing.Size(247, 22)
        Me.ControlPanelToolStripMenuItem.Text = "Run Control Panel"
        '
        'ToolStripSeparator5
        '
        Me.ToolStripSeparator5.Name = "ToolStripSeparator5"
        Me.ToolStripSeparator5.Size = New System.Drawing.Size(244, 6)
        '
        'TaskSchedulerToolStripMenuItem
        '
        Me.TaskSchedulerToolStripMenuItem.Name = "TaskSchedulerToolStripMenuItem"
        Me.TaskSchedulerToolStripMenuItem.Size = New System.Drawing.Size(247, 22)
        Me.TaskSchedulerToolStripMenuItem.Text = "Run Task Scheduler"
        '
        'ServicesToolStripMenuItem
        '
        Me.ServicesToolStripMenuItem.Name = "ServicesToolStripMenuItem"
        Me.ServicesToolStripMenuItem.Size = New System.Drawing.Size(247, 22)
        Me.ServicesToolStripMenuItem.Text = "Run Services panel"
        '
        'EventViewerToolStripMenuItem
        '
        Me.EventViewerToolStripMenuItem.Name = "EventViewerToolStripMenuItem"
        Me.EventViewerToolStripMenuItem.Size = New System.Drawing.Size(247, 22)
        Me.EventViewerToolStripMenuItem.Text = "Run Event Viewer"
        '
        'SystemConfigurationUtilityToolStripMenuItem
        '
        Me.SystemConfigurationUtilityToolStripMenuItem.Name = "SystemConfigurationUtilityToolStripMenuItem"
        Me.SystemConfigurationUtilityToolStripMenuItem.Size = New System.Drawing.Size(247, 22)
        Me.SystemConfigurationUtilityToolStripMenuItem.Text = "Run System Configuration Utility"
        '
        'ToolStripSeparator3
        '
        Me.ToolStripSeparator3.Name = "ToolStripSeparator3"
        Me.ToolStripSeparator3.Size = New System.Drawing.Size(244, 6)
        '
        'MMCToolStripMenuItem
        '
        Me.MMCToolStripMenuItem.Name = "MMCToolStripMenuItem"
        Me.MMCToolStripMenuItem.Size = New System.Drawing.Size(247, 22)
        Me.MMCToolStripMenuItem.Text = "Run MMC"
        '
        'GroupPolicyEditorToolStripMenuItem
        '
        Me.GroupPolicyEditorToolStripMenuItem.Name = "GroupPolicyEditorToolStripMenuItem"
        Me.GroupPolicyEditorToolStripMenuItem.Size = New System.Drawing.Size(247, 22)
        Me.GroupPolicyEditorToolStripMenuItem.Text = "Run Group Policy Editor"
        '
        'DiskManagementToolStripMenuItem
        '
        Me.DiskManagementToolStripMenuItem.Name = "DiskManagementToolStripMenuItem"
        Me.DiskManagementToolStripMenuItem.Size = New System.Drawing.Size(247, 22)
        Me.DiskManagementToolStripMenuItem.Text = "Run Disk Management console"
        '
        'DeviceManagementToolStripMenuItem
        '
        Me.DeviceManagementToolStripMenuItem.Name = "DeviceManagementToolStripMenuItem"
        Me.DeviceManagementToolStripMenuItem.Size = New System.Drawing.Size(247, 22)
        Me.DeviceManagementToolStripMenuItem.Text = "Run Device Manager"
        '
        'ToolStripSeparator6
        '
        Me.ToolStripSeparator6.Name = "ToolStripSeparator6"
        Me.ToolStripSeparator6.Size = New System.Drawing.Size(185, 6)
        '
        'ContextMenuToolStripMenuItem
        '
        Me.ContextMenuToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.AddRevealToolStripMenuItem, Me.AddCMDHereToolStripMenuItem, Me.AddTakeOwnershipToolStripMenuItem, Me.AddToolStripMenuItem})
        Me.ContextMenuToolStripMenuItem.Name = "ContextMenuToolStripMenuItem"
        Me.ContextMenuToolStripMenuItem.Size = New System.Drawing.Size(188, 22)
        Me.ContextMenuToolStripMenuItem.Text = "Context Menu tweaks"
        '
        'AddRevealToolStripMenuItem
        '
        Me.AddRevealToolStripMenuItem.Name = "AddRevealToolStripMenuItem"
        Me.AddRevealToolStripMenuItem.Size = New System.Drawing.Size(281, 22)
        Me.AddRevealToolStripMenuItem.Text = "Add ""Reveal"" (a toggle for Hidden files)"
        '
        'AddCMDHereToolStripMenuItem
        '
        Me.AddCMDHereToolStripMenuItem.Name = "AddCMDHereToolStripMenuItem"
        Me.AddCMDHereToolStripMenuItem.Size = New System.Drawing.Size(281, 22)
        Me.AddCMDHereToolStripMenuItem.Text = "Add ""CMD Here"""
        '
        'AddTakeOwnershipToolStripMenuItem
        '
        Me.AddTakeOwnershipToolStripMenuItem.Name = "AddTakeOwnershipToolStripMenuItem"
        Me.AddTakeOwnershipToolStripMenuItem.Size = New System.Drawing.Size(281, 22)
        Me.AddTakeOwnershipToolStripMenuItem.Text = "Add ""Take Ownership"""
        '
        'AddToolStripMenuItem
        '
        Me.AddToolStripMenuItem.Name = "AddToolStripMenuItem"
        Me.AddToolStripMenuItem.Size = New System.Drawing.Size(281, 22)
        Me.AddToolStripMenuItem.Text = "Add ""Open With Notepad"""
        '
        'HelpToolStripMenuItem
        '
        Me.HelpToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.AboutToolStripMenuItem})
        Me.HelpToolStripMenuItem.Name = "HelpToolStripMenuItem"
        Me.HelpToolStripMenuItem.Size = New System.Drawing.Size(44, 20)
        Me.HelpToolStripMenuItem.Text = "Help"
        '
        'AboutToolStripMenuItem
        '
        Me.AboutToolStripMenuItem.Name = "AboutToolStripMenuItem"
        Me.AboutToolStripMenuItem.Size = New System.Drawing.Size(107, 22)
        Me.AboutToolStripMenuItem.Text = "About"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(14, 80)
        Me.Label3.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(74, 13)
        Me.Label3.TabIndex = 30
        Me.Label3.Text = "Task Manager"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(14, 54)
        Me.Label2.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(78, 13)
        Me.Label2.TabIndex = 9
        Me.Label2.Text = "Registry Editor"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(14, 106)
        Me.Label5.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(71, 13)
        Me.Label5.TabIndex = 32
        Me.Label5.Text = "Control Panel"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(14, 28)
        Me.Label1.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(76, 13)
        Me.Label1.TabIndex = 8
        Me.Label1.Text = "Command Line"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(14, 210)
        Me.Label8.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(104, 13)
        Me.Label8.TabIndex = 35
        Me.Label8.Text = "User Profile Settings"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(14, 158)
        Me.Label9.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(77, 13)
        Me.Label9.TabIndex = 36
        Me.Label9.Text = "Folder Options"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(288, 28)
        Me.Label10.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(72, 13)
        Me.Label10.TabIndex = 37
        Me.Label10.Text = "Windows Run"
        '
        'Label35
        '
        Me.Label35.AutoSize = True
        Me.Label35.Location = New System.Drawing.Point(14, 184)
        Me.Label35.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label35.Name = "Label35"
        Me.Label35.Size = New System.Drawing.Size(113, 13)
        Me.Label35.TabIndex = 80
        Me.Label35.Text = "Administrator Account"
        '
        'Label37
        '
        Me.Label37.AutoSize = True
        Me.Label37.Location = New System.Drawing.Point(288, 53)
        Me.Label37.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label37.Name = "Label37"
        Me.Label37.Size = New System.Drawing.Size(93, 13)
        Me.Label37.TabIndex = 82
        Me.Label37.Text = "Windows Updates"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(288, 203)
        Me.Label4.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(107, 13)
        Me.Label4.TabIndex = 31
        Me.Label4.Text = "USB Write Protection"
        '
        'Label42
        '
        Me.Label42.AutoSize = True
        Me.Label42.Location = New System.Drawing.Point(288, 103)
        Me.Label42.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label42.Name = "Label42"
        Me.Label42.Size = New System.Drawing.Size(108, 13)
        Me.Label42.TabIndex = 123
        Me.Label42.Text = "Windows Hibernation"
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Location = New System.Drawing.Point(288, 128)
        Me.Label16.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(105, 13)
        Me.Label16.TabIndex = 127
        Me.Label16.Text = "Windows Script Host"
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Location = New System.Drawing.Point(14, 132)
        Me.Label18.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(54, 13)
        Me.Label18.TabIndex = 135
        Me.Label18.Text = "Safe Boot"
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.Location = New System.Drawing.Point(288, 78)
        Me.Label20.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(104, 13)
        Me.Label20.TabIndex = 141
        Me.Label20.Text = "Windows Prefeching"
        '
        'Label24
        '
        Me.Label24.AutoSize = True
        Me.Label24.Location = New System.Drawing.Point(288, 178)
        Me.Label24.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(75, 13)
        Me.Label24.TabIndex = 153
        Me.Label24.Text = "USB Detection"
        '
        'LinkLabel2
        '
        Me.LinkLabel2.AutoSize = True
        Me.LinkLabel2.Location = New System.Drawing.Point(404, 203)
        Me.LinkLabel2.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.LinkLabel2.Name = "LinkLabel2"
        Me.LinkLabel2.Size = New System.Drawing.Size(39, 13)
        Me.LinkLabel2.TabIndex = 182
        Me.LinkLabel2.TabStop = True
        Me.LinkLabel2.Text = "Enable"
        '
        'LinkLabel4
        '
        Me.LinkLabel4.AutoSize = True
        Me.LinkLabel4.Location = New System.Drawing.Point(128, 28)
        Me.LinkLabel4.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.LinkLabel4.Name = "LinkLabel4"
        Me.LinkLabel4.Size = New System.Drawing.Size(39, 13)
        Me.LinkLabel4.TabIndex = 184
        Me.LinkLabel4.TabStop = True
        Me.LinkLabel4.Text = "Enable"
        '
        'LinkLabel5
        '
        Me.LinkLabel5.AutoSize = True
        Me.LinkLabel5.Location = New System.Drawing.Point(171, 80)
        Me.LinkLabel5.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.LinkLabel5.Name = "LinkLabel5"
        Me.LinkLabel5.Size = New System.Drawing.Size(41, 13)
        Me.LinkLabel5.TabIndex = 185
        Me.LinkLabel5.TabStop = True
        Me.LinkLabel5.Text = "Disable"
        '
        'LinkLabel6
        '
        Me.LinkLabel6.AutoSize = True
        Me.LinkLabel6.Location = New System.Drawing.Point(128, 80)
        Me.LinkLabel6.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.LinkLabel6.Name = "LinkLabel6"
        Me.LinkLabel6.Size = New System.Drawing.Size(39, 13)
        Me.LinkLabel6.TabIndex = 186
        Me.LinkLabel6.TabStop = True
        Me.LinkLabel6.Text = "Enable"
        '
        'LinkLabel7
        '
        Me.LinkLabel7.AutoSize = True
        Me.LinkLabel7.Location = New System.Drawing.Point(171, 106)
        Me.LinkLabel7.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.LinkLabel7.Name = "LinkLabel7"
        Me.LinkLabel7.Size = New System.Drawing.Size(41, 13)
        Me.LinkLabel7.TabIndex = 187
        Me.LinkLabel7.TabStop = True
        Me.LinkLabel7.Text = "Disable"
        '
        'LinkLabel8
        '
        Me.LinkLabel8.AutoSize = True
        Me.LinkLabel8.Location = New System.Drawing.Point(171, 210)
        Me.LinkLabel8.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.LinkLabel8.Name = "LinkLabel8"
        Me.LinkLabel8.Size = New System.Drawing.Size(41, 13)
        Me.LinkLabel8.TabIndex = 188
        Me.LinkLabel8.TabStop = True
        Me.LinkLabel8.Text = "Disable"
        '
        'LinkLabel9
        '
        Me.LinkLabel9.AutoSize = True
        Me.LinkLabel9.Location = New System.Drawing.Point(128, 210)
        Me.LinkLabel9.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.LinkLabel9.Name = "LinkLabel9"
        Me.LinkLabel9.Size = New System.Drawing.Size(39, 13)
        Me.LinkLabel9.TabIndex = 189
        Me.LinkLabel9.TabStop = True
        Me.LinkLabel9.Text = "Enable"
        '
        'LinkLabel10
        '
        Me.LinkLabel10.AutoSize = True
        Me.LinkLabel10.Location = New System.Drawing.Point(450, 203)
        Me.LinkLabel10.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.LinkLabel10.Name = "LinkLabel10"
        Me.LinkLabel10.Size = New System.Drawing.Size(41, 13)
        Me.LinkLabel10.TabIndex = 190
        Me.LinkLabel10.TabStop = True
        Me.LinkLabel10.Text = "Disable"
        '
        'LinkLabel11
        '
        Me.LinkLabel11.AutoSize = True
        Me.LinkLabel11.Location = New System.Drawing.Point(128, 54)
        Me.LinkLabel11.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.LinkLabel11.Name = "LinkLabel11"
        Me.LinkLabel11.Size = New System.Drawing.Size(39, 13)
        Me.LinkLabel11.TabIndex = 191
        Me.LinkLabel11.TabStop = True
        Me.LinkLabel11.Text = "Enable"
        '
        'LinkLabel12
        '
        Me.LinkLabel12.AutoSize = True
        Me.LinkLabel12.Location = New System.Drawing.Point(171, 54)
        Me.LinkLabel12.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.LinkLabel12.Name = "LinkLabel12"
        Me.LinkLabel12.Size = New System.Drawing.Size(41, 13)
        Me.LinkLabel12.TabIndex = 192
        Me.LinkLabel12.TabStop = True
        Me.LinkLabel12.Text = "Disable"
        '
        'LinkLabel13
        '
        Me.LinkLabel13.AutoSize = True
        Me.LinkLabel13.Location = New System.Drawing.Point(171, 28)
        Me.LinkLabel13.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.LinkLabel13.Name = "LinkLabel13"
        Me.LinkLabel13.Size = New System.Drawing.Size(41, 13)
        Me.LinkLabel13.TabIndex = 193
        Me.LinkLabel13.TabStop = True
        Me.LinkLabel13.Text = "Disable"
        '
        'LinkLabel14
        '
        Me.LinkLabel14.AutoSize = True
        Me.LinkLabel14.Location = New System.Drawing.Point(192, 173)
        Me.LinkLabel14.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.LinkLabel14.Name = "LinkLabel14"
        Me.LinkLabel14.Size = New System.Drawing.Size(0, 13)
        Me.LinkLabel14.TabIndex = 194
        '
        'LinkLabel15
        '
        Me.LinkLabel15.AutoSize = True
        Me.LinkLabel15.Location = New System.Drawing.Point(128, 106)
        Me.LinkLabel15.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.LinkLabel15.Name = "LinkLabel15"
        Me.LinkLabel15.Size = New System.Drawing.Size(39, 13)
        Me.LinkLabel15.TabIndex = 195
        Me.LinkLabel15.TabStop = True
        Me.LinkLabel15.Text = "Enable"
        '
        'LinkLabel17
        '
        Me.LinkLabel17.AutoSize = True
        Me.LinkLabel17.Location = New System.Drawing.Point(171, 156)
        Me.LinkLabel17.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.LinkLabel17.Name = "LinkLabel17"
        Me.LinkLabel17.Size = New System.Drawing.Size(41, 13)
        Me.LinkLabel17.TabIndex = 197
        Me.LinkLabel17.TabStop = True
        Me.LinkLabel17.Text = "Disable"
        '
        'LinkLabel20
        '
        Me.LinkLabel20.AutoSize = True
        Me.LinkLabel20.Location = New System.Drawing.Point(449, 28)
        Me.LinkLabel20.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.LinkLabel20.Name = "LinkLabel20"
        Me.LinkLabel20.Size = New System.Drawing.Size(41, 13)
        Me.LinkLabel20.TabIndex = 200
        Me.LinkLabel20.TabStop = True
        Me.LinkLabel20.Text = "Disable"
        '
        'LinkLabel26
        '
        Me.LinkLabel26.AutoSize = True
        Me.LinkLabel26.Location = New System.Drawing.Point(449, 53)
        Me.LinkLabel26.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.LinkLabel26.Name = "LinkLabel26"
        Me.LinkLabel26.Size = New System.Drawing.Size(41, 13)
        Me.LinkLabel26.TabIndex = 206
        Me.LinkLabel26.TabStop = True
        Me.LinkLabel26.Text = "Disable"
        '
        'LinkLabel27
        '
        Me.LinkLabel27.AutoSize = True
        Me.LinkLabel27.Location = New System.Drawing.Point(171, 184)
        Me.LinkLabel27.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.LinkLabel27.Name = "LinkLabel27"
        Me.LinkLabel27.Size = New System.Drawing.Size(41, 13)
        Me.LinkLabel27.TabIndex = 207
        Me.LinkLabel27.TabStop = True
        Me.LinkLabel27.Text = "Disable"
        '
        'LinkLabel30
        '
        Me.LinkLabel30.AutoSize = True
        Me.LinkLabel30.Location = New System.Drawing.Point(402, 53)
        Me.LinkLabel30.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.LinkLabel30.Name = "LinkLabel30"
        Me.LinkLabel30.Size = New System.Drawing.Size(39, 13)
        Me.LinkLabel30.TabIndex = 210
        Me.LinkLabel30.TabStop = True
        Me.LinkLabel30.Text = "Enable"
        '
        'LinkLabel31
        '
        Me.LinkLabel31.AutoSize = True
        Me.LinkLabel31.Location = New System.Drawing.Point(128, 184)
        Me.LinkLabel31.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.LinkLabel31.Name = "LinkLabel31"
        Me.LinkLabel31.Size = New System.Drawing.Size(39, 13)
        Me.LinkLabel31.TabIndex = 211
        Me.LinkLabel31.TabStop = True
        Me.LinkLabel31.Text = "Enable"
        '
        'LinkLabel33
        '
        Me.LinkLabel33.AutoSize = True
        Me.LinkLabel33.Location = New System.Drawing.Point(402, 28)
        Me.LinkLabel33.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.LinkLabel33.Name = "LinkLabel33"
        Me.LinkLabel33.Size = New System.Drawing.Size(39, 13)
        Me.LinkLabel33.TabIndex = 213
        Me.LinkLabel33.TabStop = True
        Me.LinkLabel33.Text = "Enable"
        '
        'LinkLabel34
        '
        Me.LinkLabel34.AutoSize = True
        Me.LinkLabel34.Location = New System.Drawing.Point(128, 156)
        Me.LinkLabel34.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.LinkLabel34.Name = "LinkLabel34"
        Me.LinkLabel34.Size = New System.Drawing.Size(39, 13)
        Me.LinkLabel34.TabIndex = 214
        Me.LinkLabel34.TabStop = True
        Me.LinkLabel34.Text = "Enable"
        '
        'LinkLabel36
        '
        Me.LinkLabel36.AutoSize = True
        Me.LinkLabel36.Location = New System.Drawing.Point(402, 103)
        Me.LinkLabel36.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.LinkLabel36.Name = "LinkLabel36"
        Me.LinkLabel36.Size = New System.Drawing.Size(39, 13)
        Me.LinkLabel36.TabIndex = 215
        Me.LinkLabel36.TabStop = True
        Me.LinkLabel36.Text = "Enable"
        '
        'LinkLabel35
        '
        Me.LinkLabel35.AutoSize = True
        Me.LinkLabel35.Location = New System.Drawing.Point(449, 103)
        Me.LinkLabel35.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.LinkLabel35.Name = "LinkLabel35"
        Me.LinkLabel35.Size = New System.Drawing.Size(41, 13)
        Me.LinkLabel35.TabIndex = 216
        Me.LinkLabel35.TabStop = True
        Me.LinkLabel35.Text = "Disable"
        '
        'LinkLabel38
        '
        Me.LinkLabel38.AutoSize = True
        Me.LinkLabel38.Location = New System.Drawing.Point(402, 128)
        Me.LinkLabel38.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.LinkLabel38.Name = "LinkLabel38"
        Me.LinkLabel38.Size = New System.Drawing.Size(39, 13)
        Me.LinkLabel38.TabIndex = 217
        Me.LinkLabel38.TabStop = True
        Me.LinkLabel38.Text = "Enable"
        '
        'LinkLabel37
        '
        Me.LinkLabel37.AutoSize = True
        Me.LinkLabel37.Location = New System.Drawing.Point(449, 128)
        Me.LinkLabel37.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.LinkLabel37.Name = "LinkLabel37"
        Me.LinkLabel37.Size = New System.Drawing.Size(41, 13)
        Me.LinkLabel37.TabIndex = 218
        Me.LinkLabel37.TabStop = True
        Me.LinkLabel37.Text = "Disable"
        '
        'LinkLabel21
        '
        Me.LinkLabel21.AutoSize = True
        Me.LinkLabel21.Location = New System.Drawing.Point(128, 132)
        Me.LinkLabel21.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.LinkLabel21.Name = "LinkLabel21"
        Me.LinkLabel21.Size = New System.Drawing.Size(39, 13)
        Me.LinkLabel21.TabIndex = 219
        Me.LinkLabel21.TabStop = True
        Me.LinkLabel21.Text = "Enable"
        '
        'LinkLabel19
        '
        Me.LinkLabel19.AutoSize = True
        Me.LinkLabel19.Location = New System.Drawing.Point(171, 132)
        Me.LinkLabel19.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.LinkLabel19.Name = "LinkLabel19"
        Me.LinkLabel19.Size = New System.Drawing.Size(41, 13)
        Me.LinkLabel19.TabIndex = 220
        Me.LinkLabel19.TabStop = True
        Me.LinkLabel19.Text = "Disable"
        '
        'LinkLabel18
        '
        Me.LinkLabel18.AutoSize = True
        Me.LinkLabel18.Location = New System.Drawing.Point(402, 78)
        Me.LinkLabel18.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.LinkLabel18.Name = "LinkLabel18"
        Me.LinkLabel18.Size = New System.Drawing.Size(39, 13)
        Me.LinkLabel18.TabIndex = 221
        Me.LinkLabel18.TabStop = True
        Me.LinkLabel18.Text = "Enable"
        '
        'LinkLabel16
        '
        Me.LinkLabel16.AutoSize = True
        Me.LinkLabel16.Location = New System.Drawing.Point(449, 78)
        Me.LinkLabel16.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.LinkLabel16.Name = "LinkLabel16"
        Me.LinkLabel16.Size = New System.Drawing.Size(41, 13)
        Me.LinkLabel16.TabIndex = 222
        Me.LinkLabel16.TabStop = True
        Me.LinkLabel16.Text = "Disable"
        '
        'LinkLabel24
        '
        Me.LinkLabel24.AutoSize = True
        Me.LinkLabel24.Location = New System.Drawing.Point(404, 177)
        Me.LinkLabel24.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.LinkLabel24.Name = "LinkLabel24"
        Me.LinkLabel24.Size = New System.Drawing.Size(39, 13)
        Me.LinkLabel24.TabIndex = 225
        Me.LinkLabel24.TabStop = True
        Me.LinkLabel24.Text = "Enable"
        '
        'LinkLabel22
        '
        Me.LinkLabel22.AutoSize = True
        Me.LinkLabel22.Location = New System.Drawing.Point(450, 177)
        Me.LinkLabel22.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.LinkLabel22.Name = "LinkLabel22"
        Me.LinkLabel22.Size = New System.Drawing.Size(41, 13)
        Me.LinkLabel22.TabIndex = 226
        Me.LinkLabel22.TabStop = True
        Me.LinkLabel22.Text = "Disable"
        '
        'LinkLabel41
        '
        Me.LinkLabel41.AutoSize = True
        Me.LinkLabel41.Location = New System.Drawing.Point(216, 106)
        Me.LinkLabel41.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.LinkLabel41.Name = "LinkLabel41"
        Me.LinkLabel41.Size = New System.Drawing.Size(41, 13)
        Me.LinkLabel41.TabIndex = 227
        Me.LinkLabel41.TabStop = True
        Me.LinkLabel41.Text = "Launch"
        '
        'LinkLabel32
        '
        Me.LinkLabel32.AutoSize = True
        Me.LinkLabel32.Location = New System.Drawing.Point(216, 28)
        Me.LinkLabel32.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.LinkLabel32.Name = "LinkLabel32"
        Me.LinkLabel32.Size = New System.Drawing.Size(41, 13)
        Me.LinkLabel32.TabIndex = 230
        Me.LinkLabel32.TabStop = True
        Me.LinkLabel32.Text = "Launch"
        '
        'LinkLabel29
        '
        Me.LinkLabel29.AutoSize = True
        Me.LinkLabel29.Location = New System.Drawing.Point(216, 80)
        Me.LinkLabel29.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.LinkLabel29.Name = "LinkLabel29"
        Me.LinkLabel29.Size = New System.Drawing.Size(41, 13)
        Me.LinkLabel29.TabIndex = 231
        Me.LinkLabel29.TabStop = True
        Me.LinkLabel29.Text = "Launch"
        '
        'LinkLabel28
        '
        Me.LinkLabel28.AutoSize = True
        Me.LinkLabel28.Location = New System.Drawing.Point(216, 54)
        Me.LinkLabel28.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.LinkLabel28.Name = "LinkLabel28"
        Me.LinkLabel28.Size = New System.Drawing.Size(41, 13)
        Me.LinkLabel28.TabIndex = 232
        Me.LinkLabel28.TabStop = True
        Me.LinkLabel28.Text = "Launch"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(288, 153)
        Me.Label6.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(74, 13)
        Me.Label6.TabIndex = 233
        Me.Label6.Text = "Windows UAC"
        '
        'LinkLabel25
        '
        Me.LinkLabel25.AutoSize = True
        Me.LinkLabel25.Location = New System.Drawing.Point(402, 153)
        Me.LinkLabel25.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.LinkLabel25.Name = "LinkLabel25"
        Me.LinkLabel25.Size = New System.Drawing.Size(39, 13)
        Me.LinkLabel25.TabIndex = 234
        Me.LinkLabel25.TabStop = True
        Me.LinkLabel25.Text = "Enable"
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.LinkLabel23)
        Me.GroupBox1.Controls.Add(Me.LinkLabel25)
        Me.GroupBox1.Controls.Add(Me.Label6)
        Me.GroupBox1.Controls.Add(Me.LinkLabel28)
        Me.GroupBox1.Controls.Add(Me.LinkLabel29)
        Me.GroupBox1.Controls.Add(Me.LinkLabel32)
        Me.GroupBox1.Controls.Add(Me.LinkLabel41)
        Me.GroupBox1.Controls.Add(Me.LinkLabel22)
        Me.GroupBox1.Controls.Add(Me.LinkLabel24)
        Me.GroupBox1.Controls.Add(Me.LinkLabel16)
        Me.GroupBox1.Controls.Add(Me.LinkLabel18)
        Me.GroupBox1.Controls.Add(Me.LinkLabel19)
        Me.GroupBox1.Controls.Add(Me.LinkLabel21)
        Me.GroupBox1.Controls.Add(Me.LinkLabel37)
        Me.GroupBox1.Controls.Add(Me.LinkLabel38)
        Me.GroupBox1.Controls.Add(Me.LinkLabel35)
        Me.GroupBox1.Controls.Add(Me.LinkLabel36)
        Me.GroupBox1.Controls.Add(Me.LinkLabel34)
        Me.GroupBox1.Controls.Add(Me.LinkLabel33)
        Me.GroupBox1.Controls.Add(Me.LinkLabel31)
        Me.GroupBox1.Controls.Add(Me.LinkLabel30)
        Me.GroupBox1.Controls.Add(Me.LinkLabel27)
        Me.GroupBox1.Controls.Add(Me.LinkLabel26)
        Me.GroupBox1.Controls.Add(Me.LinkLabel20)
        Me.GroupBox1.Controls.Add(Me.LinkLabel17)
        Me.GroupBox1.Controls.Add(Me.LinkLabel15)
        Me.GroupBox1.Controls.Add(Me.LinkLabel14)
        Me.GroupBox1.Controls.Add(Me.LinkLabel13)
        Me.GroupBox1.Controls.Add(Me.LinkLabel12)
        Me.GroupBox1.Controls.Add(Me.LinkLabel11)
        Me.GroupBox1.Controls.Add(Me.LinkLabel10)
        Me.GroupBox1.Controls.Add(Me.LinkLabel9)
        Me.GroupBox1.Controls.Add(Me.LinkLabel8)
        Me.GroupBox1.Controls.Add(Me.LinkLabel7)
        Me.GroupBox1.Controls.Add(Me.LinkLabel6)
        Me.GroupBox1.Controls.Add(Me.LinkLabel5)
        Me.GroupBox1.Controls.Add(Me.LinkLabel4)
        Me.GroupBox1.Controls.Add(Me.LinkLabel2)
        Me.GroupBox1.Controls.Add(Me.Label24)
        Me.GroupBox1.Controls.Add(Me.Label20)
        Me.GroupBox1.Controls.Add(Me.Label18)
        Me.GroupBox1.Controls.Add(Me.Label16)
        Me.GroupBox1.Controls.Add(Me.Label42)
        Me.GroupBox1.Controls.Add(Me.Label4)
        Me.GroupBox1.Controls.Add(Me.Label37)
        Me.GroupBox1.Controls.Add(Me.Label35)
        Me.GroupBox1.Controls.Add(Me.Label10)
        Me.GroupBox1.Controls.Add(Me.Label9)
        Me.GroupBox1.Controls.Add(Me.Label8)
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Controls.Add(Me.Label5)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Controls.Add(Me.Label3)
        Me.GroupBox1.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox1.Location = New System.Drawing.Point(12, 29)
        Me.GroupBox1.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Padding = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.GroupBox1.Size = New System.Drawing.Size(510, 234)
        Me.GroupBox1.TabIndex = 124
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Option"
        '
        'LinkLabel23
        '
        Me.LinkLabel23.AutoSize = True
        Me.LinkLabel23.Location = New System.Drawing.Point(449, 153)
        Me.LinkLabel23.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.LinkLabel23.Name = "LinkLabel23"
        Me.LinkLabel23.Size = New System.Drawing.Size(41, 13)
        Me.LinkLabel23.TabIndex = 235
        Me.LinkLabel23.TabStop = True
        Me.LinkLabel23.Text = "Disable"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(533, 275)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.MenuStrip1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.MaximizeBox = False
        Me.Name = "Form1"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Scriptz"
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents MenuStrip1 As MenuStrip
    Friend WithEvents FileToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ExitToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ToolsToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents SafeToolsToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents GregsDOSShellToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents SafeREGEDITToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents RecoveryToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents CommandPromptToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents RegistryEditorToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents TaskManagerToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ControlPanelToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents SystemConfigurationUtilityToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents EnableAdministratorAccountToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents TaskSchedulerToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents HelpToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents AboutToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents RepairToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ResetWindowsFirewallDefaultsToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ContextMenuToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents AddToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents AddTakeOwnershipToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents AddCMDHereToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem2 As ToolStripMenuItem
    Friend WithEvents AddRevealToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ClearToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents PrefetchToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents RunMRUToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents DNSCacheToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents RecentFilesToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents IEBrowsingActivityToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ClearEventsViewerLogToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents Label3 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents Label10 As Label
    Friend WithEvents Label35 As Label
    Friend WithEvents Label37 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label42 As Label
    Friend WithEvents Label16 As Label
    Friend WithEvents Label18 As Label
    Friend WithEvents Label20 As Label
    Friend WithEvents Label24 As Label
    Friend WithEvents LinkLabel2 As LinkLabel
    Friend WithEvents LinkLabel4 As LinkLabel
    Friend WithEvents LinkLabel5 As LinkLabel
    Friend WithEvents LinkLabel6 As LinkLabel
    Friend WithEvents LinkLabel7 As LinkLabel
    Friend WithEvents LinkLabel8 As LinkLabel
    Friend WithEvents LinkLabel9 As LinkLabel
    Friend WithEvents LinkLabel10 As LinkLabel
    Friend WithEvents LinkLabel11 As LinkLabel
    Friend WithEvents LinkLabel12 As LinkLabel
    Friend WithEvents LinkLabel13 As LinkLabel
    Friend WithEvents LinkLabel14 As LinkLabel
    Friend WithEvents LinkLabel15 As LinkLabel
    Friend WithEvents LinkLabel17 As LinkLabel
    Friend WithEvents LinkLabel20 As LinkLabel
    Friend WithEvents LinkLabel26 As LinkLabel
    Friend WithEvents LinkLabel27 As LinkLabel
    Friend WithEvents LinkLabel30 As LinkLabel
    Friend WithEvents LinkLabel31 As LinkLabel
    Friend WithEvents LinkLabel33 As LinkLabel
    Friend WithEvents LinkLabel34 As LinkLabel
    Friend WithEvents LinkLabel36 As LinkLabel
    Friend WithEvents LinkLabel35 As LinkLabel
    Friend WithEvents LinkLabel38 As LinkLabel
    Friend WithEvents LinkLabel37 As LinkLabel
    Friend WithEvents LinkLabel21 As LinkLabel
    Friend WithEvents LinkLabel19 As LinkLabel
    Friend WithEvents LinkLabel18 As LinkLabel
    Friend WithEvents LinkLabel16 As LinkLabel
    Friend WithEvents LinkLabel24 As LinkLabel
    Friend WithEvents LinkLabel22 As LinkLabel
    Friend WithEvents LinkLabel41 As LinkLabel
    Friend WithEvents LinkLabel32 As LinkLabel
    Friend WithEvents LinkLabel29 As LinkLabel
    Friend WithEvents LinkLabel28 As LinkLabel
    Friend WithEvents Label6 As Label
    Friend WithEvents LinkLabel25 As LinkLabel
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents LinkLabel23 As LinkLabel
    Friend WithEvents RestartExplorerToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ProcessExplorer32BitToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ToolStripSeparator1 As ToolStripSeparator
    Friend WithEvents ToolStripSeparator4 As ToolStripSeparator
    Friend WithEvents MMCToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents GroupPolicyEditorToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ServicesToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents EventViewerToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents DiskManagementToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents DeviceManagementToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ToolStripSeparator5 As ToolStripSeparator
    Friend WithEvents ToolStripSeparator3 As ToolStripSeparator
    Friend WithEvents ToolStripSeparator7 As ToolStripSeparator
    Friend WithEvents ToolStripSeparator6 As ToolStripSeparator
    Friend WithEvents RunAutorunsToolStripMenuItem As ToolStripMenuItem
End Class
